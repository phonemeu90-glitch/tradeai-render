/**
 * Dashboard — Painel do Usuário com Integração de Autenticação
 */
import { useState, useEffect, useCallback, useRef } from "react";
import Layout from "@/components/Layout";
import ExtraordinaryChart from "@/components/ExtraordinaryChart";
import DepositNotification from "@/components/DepositNotification";
import { useTrading } from "@/contexts/TradingContext";
import { useAuth } from "@/contexts/AuthContext";
import { useChart } from "@/contexts/ChartContext";
import { useLocation } from "wouter";
import {
  TrendingUp, TrendingDown, DollarSign, Zap, ArrowUpRight,
  ArrowDownRight, RefreshCw, Brain, Target, Activity, Wallet,
  Plus, Minus, Eye, EyeOff, Clock, CheckCircle2, AlertTriangle, LogOut
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// ── Seeded PRNG: mesmo símbolo + mesmo dia → mesmos candles históricos ──
function hashCode(str: string): number {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
  return Math.abs(h) || 1;
}
function seededRand(seed: number) {
  let s = (seed ^ 0xdeadbeef) >>> 0;
  return () => { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return (s >>> 0) / 0xFFFFFFFF; };
}
function generateCandleData(points: number, startPrice: number, symbol = "DEFAULT") {
  const dateKey = new Date().toISOString().slice(0, 10);
  const rand = seededRand(hashCode(symbol + dateKey));
  const data = [];
  let price = startPrice;
  const now = new Date();
  const vol = startPrice > 10000 ? 0.009 : startPrice > 1000 ? 0.011 : startPrice > 10 ? 0.014 : 0.018;
  for (let i = points; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 60 * 1000);
    const open = price;
    const change = (rand() - 0.48) * price * vol;
    const close = Math.max(open + change, price * 0.0001);
    const wick = rand() * price * vol * 0.4;
    const dec = startPrice >= 100 ? 2 : startPrice >= 1 ? 4 : 5;
    data.push({
      time: time.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
      open: parseFloat(open.toFixed(dec)), close: parseFloat(close.toFixed(dec)),
      high: parseFloat((Math.max(open, close) + wick).toFixed(dec)),
      low: parseFloat((Math.min(open, close) - wick * 0.6).toFixed(dec)),
      volume: Math.floor(rand() * 60000 + 15000),
      price: parseFloat(close.toFixed(dec)),
    });
    price = close;
  }
  return data;
}

const ASSETS = [
  { symbol: "EUR/USD", name: "Euro / Dólar OTC",        startPrice: 1.08752, color: "#3b82f6" },
  { symbol: "GBP/USD", name: "Libra / Dólar OTC",       startPrice: 1.25401, color: "#06b6d4" },
  { symbol: "USD/JPY", name: "Dólar / Iene OTC",         startPrice: 149.524, color: "#8b5cf6" },
  { symbol: "AUD/USD", name: "Dólar Aus / USD OTC",     startPrice: 0.64283, color: "#f59e0b" },
  { symbol: "EUR/GBP", name: "Euro / Libra OTC",        startPrice: 0.86721, color: "#10b981" },
  { symbol: "USD/CHF", name: "Dólar / Franco OTC",      startPrice: 0.90122, color: "#ec4899" },
  { symbol: "NZD/USD", name: "Dólar NZ / USD OTC",      startPrice: 0.59341, color: "#f97316" },
  { symbol: "BTC/USD", name: "Bitcoin / Dólar OTC",     startPrice: 67842.0, color: "#fbbf24" },
  { symbol: "ETH/USD", name: "Ethereum / Dólar OTC",    startPrice: 3521.50, color: "#6366f1" },
  { symbol: "AMAZON",  name: "Amazon OTC",               startPrice: 178.250, color: "#fb923c" },
  { symbol: "APPLE",   name: "Apple OTC",                startPrice: 189.441, color: "#e5e7eb" },
  { symbol: "TESLA",   name: "Tesla OTC",                startPrice: 175.820, color: "#f87171" },
  { symbol: "MSFT",    name: "Microsoft OTC",            startPrice: 415.330, color: "#22d3ee" },
  { symbol: "GOLD",    name: "Ouro / Dólar OTC",         startPrice: 2295.50, color: "#fbbf24" },
  { symbol: "PETR4",   name: "Petrobras OTC",            startPrice: 38.4200, color: "#34d399" },
];

export default function Dashboard() {
  const { user, logout, updateBalance, updatePnL } = useAuth();
  const { accounts, activeAccount, setActiveAccount, getAccountPnL, updatePositionPrice, syncBalance } = useTrading();
  const { updateChartData, updatePrice } = useChart();
  const [, setLocation] = useLocation();
  const [selectedAsset, setSelectedAsset] = useState(() => {
    const s = localStorage.getItem("tradeai_dash_asset");
    const n = s ? parseInt(s, 10) : 0;
    return isNaN(n) || n >= ASSETS.length ? 0 : n;
  });
  const [chartData, setChartData] = useState(() => {
    const s = localStorage.getItem("tradeai_dash_asset");
    const n = s ? parseInt(s, 10) : 0;
    const idx = isNaN(n) || n >= ASSETS.length ? 0 : n;
    return generateCandleData(80, ASSETS[idx].startPrice, ASSETS[idx].symbol);
  });
  const [currentPrice, setCurrentPrice] = useState(() => {
    const s = localStorage.getItem("tradeai_dash_asset");
    const n = s ? parseInt(s, 10) : 0;
    const idx = isNaN(n) || n >= ASSETS.length ? 0 : n;
    return ASSETS[idx].startPrice;
  });
  const [priceChange, setPriceChange] = useState(0);
  const [showBalance, setShowBalance] = useState(true);
  const [depositNotification, setDepositNotification] = useState<any>(null);
  const [rejectedNotifications, setRejectedNotifications] = useState<Map<string, any>>(new Map());

  const { refreshUser } = useAuth();

  // Carregar notificacao de deposito do usuario consultando a API
  useEffect(() => {
    if (user?.email) {
      // Consultar a API para verificar depósitos pendentes
      fetch(`/api/deposits/pending/${encodeURIComponent(user.email)}`)
        .then((res) => res.json())
        .then((deposits) => {
          if (deposits && deposits.length > 0) {
            // Há depósitos pendentes
            const deposit = deposits[0];
            const notification = {
              id: deposit.id,
              type: "pending",
              message: `Deposito de R$ ${deposit.totalAmount.toFixed(2)} em analise`,
              timestamp: new Date(deposit.timestamp).getTime(),
              userEmail: user.email,
            };
            setDepositNotification(notification);
          } else {
            // Nenhum depósito pendente
            setDepositNotification(null);
          }
        })
        .catch((e) => console.error("Erro ao carregar depositos:", e));
    }
  }, [user?.email]);

  // Sincronizar notificacoes a cada 5 segundos (polling)
  useEffect(() => {
    if (!user?.email) return;

    const interval = setInterval(() => {
      // Buscar TODOS os depositos do usuario (pendentes, aprovados, rejeitados)
      fetch(`/api/deposits/user/${encodeURIComponent(user.email)}`)
        .then((res) => res.json())
        .then((allDeposits) => {
          // Verificar se ha depositos pendentes
          const pending = allDeposits.find((d: any) => d.status === "pending");
          if (pending) {
            const notification = {
              id: pending.id,
              type: "pending",
              message: `Deposito de R$ ${pending.totalAmount.toFixed(2)} em analise`,
              timestamp: new Date(pending.timestamp).getTime(),
              userEmail: user.email,
            };
            setDepositNotification(notification);
          } else {
            setDepositNotification(null);
          }
          
          // Verificar se ha depositos rejeitados que ainda nao foram fechados
          const dismissed = JSON.parse(localStorage.getItem(`dismissed_rejections_${user.email}`) || "[]");
          const rejected = allDeposits.filter((d: any) => d.status === "rejected" && !dismissed.includes(d.id));
          const newRejectedMap = new Map();
          
          rejected.forEach((deposit: any) => {
            newRejectedMap.set(deposit.id, {
              id: deposit.id,
              type: "rejected",
              message: `Seu deposito de R$ ${deposit.amount.toFixed(2)} foi rejeitado`,
              reason: deposit.rejectedReason || "Rejeitado pelo administrador",
              timestamp: new Date(deposit.timestamp).getTime(),
              userEmail: user.email,
            });
          });
          
          setRejectedNotifications(newRejectedMap);
        })
        .catch((e) => console.error("Erro ao sincronizar depositos:", e));
    }, 5000);

    return () => clearInterval(interval);
  }, [user?.email, rejectedNotifications]);

  // Sincronizar dados ao montar
  useEffect(() => {
    if (user) {
      refreshUser();
    }
  }, [user, refreshUser]);

  const asset = ASSETS[selectedAsset] || ASSETS[0];
  const account = accounts[activeAccount] || accounts.demo;
  const pnl = getAccountPnL(activeAccount) || { total: 0, percent: 0 };

  // Sincronizar saldo entre Contextos (Auth -> Trading)
  // Isso garante que se o admin aprovar um depósito, o TradingContext receba o novo valor
  useEffect(() => {
    if (user) {
      const authBalance = activeAccount === "demo" ? user.demoBalance : user.realBalance;
      if (account && authBalance !== account.balance) {
        // Se o saldo do Auth for diferente do Trading, confiamos no Auth (que vem do servidor)
        syncBalance(activeAccount, authBalance);
        
        // Remover notificacao de analise quando o saldo mudar (indica aprovacao)
        if (depositNotification?.type === "pending") {
          localStorage.removeItem(`deposit_notification_${user.email}`);
          setDepositNotification(null);
        }
      }
    }
  }, [user, activeAccount, account?.balance, syncBalance, depositNotification?.type, user?.email]);

  // Sincronizar P&L com AuthContext
  useEffect(() => {
    if (user) {
      updatePnL(activeAccount, pnl.total);
    }
  }, [pnl, activeAccount, user, updatePnL]);

  // Refs para acessar valores atuais dentro do intervalo sem re-criar o timer
  const activeAccountRef = useRef(activeAccount);
  const accountRef = useRef(account);
  const updatePositionPriceRef = useRef(updatePositionPrice);
  const updateChartDataRef = useRef(updateChartData);
  useEffect(() => { activeAccountRef.current = activeAccount; }, [activeAccount]);
  useEffect(() => { accountRef.current = account; }, [account]);
  useEffect(() => { updatePositionPriceRef.current = updatePositionPrice; }, [updatePositionPrice]);
  useEffect(() => { updateChartDataRef.current = updateChartData; }, [updateChartData]);

  const refreshData = useCallback(() => {
    const newData = generateCandleData(80, asset.startPrice, asset.symbol);
    setChartData(newData);
    const last = newData[newData.length - 1];
    const first = newData[0];
    setCurrentPrice(last.price);
    setPriceChange(((last.price - first.price) / first.price) * 100);
    updateChartData(asset.symbol, newData);
    updatePrice(asset.symbol, last.price);
  }, [asset.startPrice, asset.symbol, updateChartData, updatePrice]);

  // Regenera apenas ao trocar ativo — NÃO ao trocar conta
  useEffect(() => {
    refreshData();
  }, [asset.symbol]); // eslint-disable-line react-hooks/exhaustive-deps

  // Intervalo de tick — não depende de activeAccount nem positions (usa refs)
  useEffect(() => {
    const dec = asset.startPrice >= 100 ? 2 : asset.startPrice >= 1 ? 4 : 5;
    const vol = asset.startPrice > 10000 ? 0.0006 : asset.startPrice > 1000 ? 0.0008 : asset.startPrice > 10 ? 0.0010 : 0.0015;
    const interval = setInterval(() => {
      setChartData((prev) => {
        if (!prev || prev.length === 0) return prev;
        const last = prev[prev.length - 1];
        const change = (Math.random() - 0.48) * last.price * vol;
        const newPrice = parseFloat((last.price + change).toFixed(dec));
        const now = new Date();
        const wick = Math.abs(change) * 0.4;
        const newPoint = {
          time: now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
          open: last.price, close: newPrice,
          high: parseFloat((Math.max(last.price, newPrice) + wick).toFixed(dec)),
          low: parseFloat((Math.min(last.price, newPrice) - wick * 0.6).toFixed(dec)),
          price: newPrice,
          volume: Math.floor(Math.random() * 80000 + 20000),
        };
        const updated = [...prev.slice(-199), newPoint];
        setCurrentPrice(newPrice);
        if (updated[0]) setPriceChange(((newPrice - updated[0].price) / updated[0].price) * 100);
        updateChartDataRef.current(asset.symbol, updated);

        const acc = accountRef.current;
        const acc_id = activeAccountRef.current;
        if (acc?.positions) {
          acc.positions.forEach((pos) => updatePositionPriceRef.current(acc_id, pos.id, newPrice));
        }
        return updated;
      });
    }, 1200);
    return () => clearInterval(interval);
  }, [asset.symbol, asset.startPrice]); // apenas símbolo — conta não reinicia o timer

  const isPositive = priceChange >= 0;
  const balance = activeAccount === "demo" ? user?.demoBalance || 0 : user?.realBalance || 0;

  const handleLogout = () => {
    logout();
    setLocation("/auth");
    toast.success("Deslogado com sucesso");
  };

  const handleDismissNotification = (id: string) => {
    // Remover notificacao de rejeição quando o usuário clicar no X
    const newRejectedMap = new Map(rejectedNotifications);
    newRejectedMap.delete(id);
    setRejectedNotifications(newRejectedMap);
    
    // Salvar no localStorage para persistir a decisão do usuário
    if (user?.email) {
      const dismissedIds = JSON.parse(localStorage.getItem(`dismissed_rejections_${user.email}`) || "[]");
      if (!dismissedIds.includes(id)) {
        dismissedIds.push(id);
        localStorage.setItem(`dismissed_rejections_${user.email}`, JSON.stringify(dismissedIds));
      }
    }
  };

  return (
    <Layout>
      {/* Notificação de Depósito em Análise (Azul) */}
      <DepositNotification
        notification={depositNotification}
        currentUserEmail={user?.email}
        onDismiss={handleDismissNotification}
      />
      
      {/* Notificações de Rejeição (Vermelhas com X) */}
      {Array.from(rejectedNotifications.values()).map((notification) => (
        <DepositNotification
          key={notification.id}
          notification={notification}
          currentUserEmail={user?.email}
          onDismiss={handleDismissNotification}
        />
      ))}
      <div className="p-4 lg:p-6 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white" style={{ fontFamily: "Sora, sans-serif" }}>
              Bem-vindo, {user?.name || "Trader"}!
            </h1>
            <p className="text-sm text-white/40 mt-0.5">Sua conta {activeAccount === "demo" ? "Demo" : "Real"} está ativa</p>
          </div>
          <div className="flex gap-2">
            {user?.isAdmin && (
              <Link href="/admin">
                <Button className="gap-2 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 border border-purple-500/30" variant="ghost">
                  🔐 Admin
                </Button>
              </Link>
            )}
            <Button
              onClick={handleLogout}
              className="gap-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30"
              variant="ghost"
            >
              <LogOut className="w-4 h-4" /> Sair
            </Button>
          </div>
        </div>

        {/* Account Selector */}
        <div className="flex gap-2">
          {["demo", "real"].map((acc) => (
            <button
              key={acc}
              onClick={() => setActiveAccount(acc as "demo" | "real")}
              className={cn(
                "px-4 py-2 rounded-xl text-sm font-semibold transition-all",
                activeAccount === acc
                  ? "bg-blue-500/20 text-blue-400 border border-blue-500/30"
                  : "text-white/40 hover:text-white/70 border border-white/10"
              )}
            >
              {acc === "demo" ? "📚 Conta Demo" : "💰 Conta Real"}
            </button>
          ))}
        </div>

        {/* Asset Selector — scroll horizontal, 15 ativos OTC */}
        <div className="glass-card rounded-2xl p-3">
          <p className="text-[10px] text-white/30 uppercase tracking-wider font-semibold mb-2 px-1">Ativos OTC disponíveis</p>
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none" style={{ scrollbarWidth: "none" }}>
            {ASSETS.map((a, i) => (
              <button
                key={i}
                onClick={() => { setSelectedAsset(i); localStorage.setItem("tradeai_dash_asset", String(i)); }}
                className="flex-shrink-0 flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all"
                style={
                  selectedAsset === i
                    ? { background: `${a.color}20`, border: `1px solid ${a.color}50`, boxShadow: `0 0 10px ${a.color}20` }
                    : { background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)" }
                }
              >
                <div
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-[9px] font-bold text-white flex-shrink-0"
                  style={{ background: `${a.color}25` }}
                >
                  {a.symbol.replace("/", "").substring(0, 3)}
                </div>
                <p className="text-[10px] font-bold text-white whitespace-nowrap" style={{ color: selectedAsset === i ? a.color : "rgba(255,255,255,0.7)" }}>
                  {a.symbol}
                </p>
              </button>
            ))}
          </div>
        </div>

        {/* Saldos */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Saldo Disponível */}
          <div className="glass-card rounded-2xl p-5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-white/50 uppercase">Saldo Disponível</span>
              <button
                onClick={() => setShowBalance(!showBalance)}
                className="text-white/40 hover:text-white/70"
              >
                {showBalance ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-2xl font-bold text-white font-mono">
              {showBalance ? `R$ ${(balance || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}` : "••••••"}
            </p>
            <p className="text-xs text-white/40 mt-1">Conta {activeAccount}</p>
          </div>

          {/* P&L Total */}
          <div className="glass-card rounded-2xl p-5">
            <span className="text-xs font-semibold text-white/50 uppercase">P&L Total</span>
            <p className={cn("text-2xl font-bold font-mono mt-2", pnl.total >= 0 ? "text-green-400" : "text-red-400")}>
              {(pnl?.total || 0) >= 0 ? "+" : ""}{(pnl?.total || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </p>
            <p className={cn("text-xs mt-1", pnl.percent >= 0 ? "text-green-400/60" : "text-red-400/60")}>
              {pnl.percent >= 0 ? "+" : ""}{pnl.percent.toFixed(2)}%
            </p>
          </div>

          {/* Posições Abertas */}
          <div className="glass-card rounded-2xl p-5">
            <span className="text-xs font-semibold text-white/50 uppercase">Posições Abertas</span>
            <p className="text-2xl font-bold text-white font-mono mt-2">{account.positions.length}</p>
            <p className="text-xs text-white/40 mt-1">
              {account.positions.length === 0 ? "Nenhuma operação" : account.positions.length + " ativa(s)"}
            </p>
          </div>
        </div>

        {/* Gráfico */}
        <div className="glass-card rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-bold text-white" style={{ fontFamily: "Sora, sans-serif" }}>
                {asset.symbol}
              </h2>
              <p className="text-xs text-white/40">{asset.name}</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-white font-mono">R$ {currentPrice.toFixed(2)}</p>
              <p className={cn("text-sm font-semibold flex items-center justify-end gap-1", isPositive ? "text-green-400" : "text-red-400")}>
                {isPositive ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                {isPositive ? "+" : ""}{priceChange.toFixed(2)}%
              </p>
            </div>
          </div>

          <ExtraordinaryChart
            data={chartData}
            currentPrice={currentPrice}
            assetColor={asset.color}
            assetSymbol={asset.symbol}
            isPositive={isPositive}
            priceChange={priceChange}
          />

          <div className="flex gap-3 mt-4">
            <Link href="/trade" className="flex-1">
              <Button className="w-full gap-2 font-semibold" style={{ background: "linear-gradient(135deg, #22c55e, #16a34a)", border: "none", cursor: "pointer" }}>
                <TrendingUp className="w-4 h-4" />
                Operar
              </Button>
            </Link>
            <Link href="/deposit" className="flex-1">
              <Button variant="outline" className="w-full gap-2 font-semibold border-white/10 text-white hover:bg-white/5" style={{ cursor: "pointer" }}>
                <Plus className="w-4 h-4" />
                Depositar
              </Button>
            </Link>
          </div>
        </div>

        {/* Posições Abertas */}
        {account.positions.length > 0 && (
          <div className="glass-card rounded-2xl p-5">
            <h3 className="text-sm font-bold text-white mb-3" style={{ fontFamily: "Sora, sans-serif" }}>
              Posições Abertas ({account.positions.length})
            </h3>
            <div className="space-y-2">
              {account.positions.map((pos) => (
                <div key={pos.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-white/3 transition-all" style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                  <div className={cn("w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0", pos.type === "call" ? "bg-green-500/20" : "bg-red-500/20")}>
                    {pos.type === "call" ? <TrendingUp className="w-4 h-4 text-green-400" /> : <TrendingDown className="w-4 h-4 text-red-400" />}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-white">{pos.asset}</p>
                    <p className="text-xs text-white/40">R$ {pos.betAmount.toFixed(2)} @ R$ {pos.entryPrice.toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Histórico */}
        {account.closedPositions.length > 0 && (
          <div className="glass-card rounded-2xl p-5">
            <h3 className="text-sm font-bold text-white mb-3" style={{ fontFamily: "Sora, sans-serif" }}>
              Histórico ({account.closedPositions.length})
            </h3>
            <div className="space-y-2">
              {account.closedPositions.slice(-5).map((pos) => (
                <div key={pos.id} className="flex items-center gap-3 p-3 rounded-lg" style={{ background: "rgba(255,255,255,0.03)" }}>
                  <CheckCircle2 className="w-4 h-4 text-white/40 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-white">{pos.asset} - {pos.type === "call" ? "CALL" : "PUT"}</p>
                    <p className="text-xs text-white/40">R$ {pos.entryPrice.toFixed(2)} → R$ {pos.exitPrice?.toFixed(2)}</p>
                  </div>
                  <p className={cn("text-sm font-bold", pos.result === "win" ? "text-green-400" : "text-red-400")}>
                    {pos.result === "win" ? "✅" : "❌"}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
