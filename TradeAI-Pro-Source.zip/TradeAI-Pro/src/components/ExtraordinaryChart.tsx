/**
 * ExtraordinaryChart — Gráfico Profissional Estilo IQ Option
 * Canvas-based, candlesticks, volume bars, price axis à direita, label de preço atual
 */
import { useEffect, useRef, useCallback } from "react";

interface CandleData {
  time: string;
  open: number;
  close: number;
  high: number;
  low: number;
  volume: number;
  price: number;
}

interface ExtraordinaryChartProps {
  data: CandleData[];
  currentPrice: number;
  assetColor: string;
  assetSymbol: string;
  isPositive: boolean;
  priceChange: number;
}

export default function ExtraordinaryChart({
  data,
  currentPrice,
  assetColor,
  assetSymbol,
  isPositive,
  priceChange,
}: ExtraordinaryChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number>(0);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !data || data.length < 2) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const displayW = canvas.parentElement?.clientWidth || 800;
    const displayH = 400;

    if (canvas.width !== displayW * dpr || canvas.height !== displayH * dpr) {
      canvas.width = displayW * dpr;
      canvas.height = displayH * dpr;
      canvas.style.width = displayW + "px";
      canvas.style.height = displayH + "px";
      ctx.scale(dpr, dpr);
    }

    const W = displayW;
    const H = displayH;

    const PRICE_AXIS_W = 72;
    const TIME_AXIS_H = 22;
    const VOL_H = 38;
    const PADDING_TOP = 12;
    const PADDING_LEFT = 6;

    const chartW = W - PADDING_LEFT - PRICE_AXIS_W;
    const chartH = H - PADDING_TOP - TIME_AXIS_H - VOL_H - 4;

    // ── Background ──
    ctx.fillStyle = "#0d1421";
    ctx.fillRect(0, 0, W, H);

    const visible = data.slice(-Math.min(data.length, 80));
    if (visible.length < 2) return;

    const allLows = visible.map(d => d.low);
    const allHighs = visible.map(d => d.high);
    let minP = Math.min(...allLows);
    let maxP = Math.max(...allHighs);
    const padP = (maxP - minP) * 0.12;
    minP -= padP;
    maxP += padP;
    const priceRange = maxP - minP || 1;

    const maxVol = Math.max(...visible.map(d => d.volume), 1);

    const toY = (p: number) => PADDING_TOP + chartH - ((p - minP) / priceRange) * chartH;
    const toX = (i: number) => PADDING_LEFT + (i / (visible.length)) * chartW + chartW / visible.length / 2;

    // ── Horizontal grid lines (price) ──
    const GRID_LINES = 8;
    ctx.lineWidth = 1;
    for (let i = 0; i <= GRID_LINES; i++) {
      const price = minP + (priceRange / GRID_LINES) * i;
      const y = toY(price);
      ctx.strokeStyle = "rgba(255,255,255,0.05)";
      ctx.beginPath();
      ctx.moveTo(PADDING_LEFT, y);
      ctx.lineTo(W - PRICE_AXIS_W, y);
      ctx.stroke();

      // Price label on right axis
      ctx.fillStyle = "rgba(255,255,255,0.35)";
      ctx.font = "10px 'Inter', sans-serif";
      ctx.textAlign = "left";
      const label = price >= 1000 ? price.toFixed(2) : price >= 10 ? price.toFixed(3) : price.toFixed(5);
      ctx.fillText(label, W - PRICE_AXIS_W + 4, y + 4);
    }

    // ── Vertical grid lines (time) ──
    const timeStep = Math.max(1, Math.floor(visible.length / 6));
    for (let i = 0; i < visible.length; i += timeStep) {
      const x = toX(i);
      ctx.strokeStyle = "rgba(255,255,255,0.04)";
      ctx.beginPath();
      ctx.moveTo(x, PADDING_TOP);
      ctx.lineTo(x, H - TIME_AXIS_H - VOL_H - 4);
      ctx.stroke();

      ctx.fillStyle = "rgba(255,255,255,0.3)";
      ctx.font = "9px 'Inter', sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(visible[i].time, x, H - VOL_H - 6);
    }

    // ── Volume bars ──
    const volTop = H - VOL_H - TIME_AXIS_H + 4;
    const volH = VOL_H - 6;
    visible.forEach((d, i) => {
      const x = toX(i);
      const cw = Math.max(1, chartW / visible.length - 1.5);
      const h = (d.volume / maxVol) * volH;
      const isGreen = d.close >= d.open;
      ctx.fillStyle = isGreen ? "rgba(34,197,94,0.25)" : "rgba(239,68,68,0.25)";
      ctx.fillRect(x - cw / 2, volTop + volH - h, cw, h);
    });

    // ── Area fill under current price ──
    const lastPrice = visible[visible.length - 1].price;
    const lastY = toY(lastPrice);
    const areaGrad = ctx.createLinearGradient(0, PADDING_TOP, 0, PADDING_TOP + chartH);
    areaGrad.addColorStop(0, isPositive ? "rgba(34,197,94,0.12)" : "rgba(239,68,68,0.06)");
    areaGrad.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = areaGrad;
    ctx.beginPath();
    ctx.moveTo(toX(0), lastY);
    visible.forEach((d, i) => ctx.lineTo(toX(i), toY(d.price)));
    ctx.lineTo(toX(visible.length - 1), PADDING_TOP + chartH);
    ctx.lineTo(toX(0), PADDING_TOP + chartH);
    ctx.closePath();
    ctx.fill();

    // ── Candlesticks ──
    const cw = Math.max(1.5, chartW / visible.length - 1.8);
    visible.forEach((d, i) => {
      const x = toX(i);
      const openY = toY(d.open);
      const closeY = toY(d.close);
      const highY = toY(d.high);
      const lowY = toY(d.low);
      const isGreen = d.close >= d.open;
      const col = isGreen ? "#26a69a" : "#ef5350";
      const colAlpha = isGreen ? "rgba(38,166,154,0.6)" : "rgba(239,83,80,0.6)";

      // Wick
      ctx.strokeStyle = colAlpha;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x, highY);
      ctx.lineTo(x, lowY);
      ctx.stroke();

      // Body
      const bodyTop = Math.min(openY, closeY);
      const bodyH = Math.max(1.5, Math.abs(closeY - openY));
      ctx.fillStyle = col;
      ctx.globalAlpha = 0.88;
      ctx.fillRect(x - cw / 2, bodyTop, cw, bodyH);
      ctx.globalAlpha = 1;
    });

    // ── Current price dashed line ──
    const cpY = toY(currentPrice);
    ctx.setLineDash([4, 4]);
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = assetColor;
    ctx.globalAlpha = 0.7;
    ctx.beginPath();
    ctx.moveTo(PADDING_LEFT, cpY);
    ctx.lineTo(W - PRICE_AXIS_W, cpY);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.globalAlpha = 1;

    // ── Pulsing dot at current price ──
    const dotX = W - PRICE_AXIS_W - 4;
    const pulse = 5 + Math.sin(Date.now() / 280) * 1.5;
    ctx.fillStyle = assetColor;
    ctx.globalAlpha = 0.9;
    ctx.beginPath();
    ctx.arc(dotX, cpY, pulse, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = assetColor;
    ctx.lineWidth = 1.5;
    ctx.globalAlpha = 0.35;
    ctx.beginPath();
    ctx.arc(dotX, cpY, pulse + 5, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 1;

    // ── Current price label box on right axis ──
    const priceLabel = currentPrice >= 1000 ? currentPrice.toFixed(2) : currentPrice >= 10 ? currentPrice.toFixed(3) : currentPrice.toFixed(5);
    const boxW = PRICE_AXIS_W - 2;
    const boxH = 18;
    const boxX = W - PRICE_AXIS_W + 1;
    const boxY = cpY - boxH / 2;
    ctx.fillStyle = assetColor;
    ctx.globalAlpha = 0.92;
    ctx.beginPath();
    ctx.roundRect(boxX, boxY, boxW, boxH, 4);
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.fillStyle = "#000";
    ctx.font = "bold 10px 'Inter', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(priceLabel, boxX + boxW / 2, cpY + 4);

    // ── Last candle highlight ──
    const lastIdx = visible.length - 1;
    const lastCandle = visible[lastIdx];
    if (lastCandle) {
      const lx = toX(lastIdx);
      const lo = toY(lastCandle.open);
      const lc = toY(lastCandle.close);
      const isGreenL = lastCandle.close >= lastCandle.open;
      ctx.fillStyle = isGreenL ? "rgba(38,166,154,0.3)" : "rgba(239,83,80,0.3)";
      ctx.fillRect(lx - cw / 2 - 2, Math.min(lo, lc) - 2, cw + 4, Math.abs(lc - lo) + 4);
    }

    // ── Border between chart and price axis ──
    ctx.strokeStyle = "rgba(255,255,255,0.08)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(W - PRICE_AXIS_W, PADDING_TOP);
    ctx.lineTo(W - PRICE_AXIS_W, H - TIME_AXIS_H - VOL_H);
    ctx.stroke();

    // ── Volume label ──
    ctx.strokeStyle = "rgba(255,255,255,0.05)";
    ctx.beginPath();
    ctx.moveTo(PADDING_LEFT, volTop);
    ctx.lineTo(W - PRICE_AXIS_W, volTop);
    ctx.stroke();
    ctx.fillStyle = "rgba(255,255,255,0.18)";
    ctx.font = "9px 'Inter', sans-serif";
    ctx.textAlign = "left";
    ctx.fillText("VOL", PADDING_LEFT + 4, volTop + 10);

  }, [data, currentPrice, assetColor, isPositive, assetSymbol]);

  useEffect(() => {
    let running = true;
    const loop = () => {
      if (!running) return;
      draw();
      animFrameRef.current = requestAnimationFrame(loop);
    };
    loop();
    return () => {
      running = false;
      cancelAnimationFrame(animFrameRef.current);
    };
  }, [draw]);

  return (
    <div
      className="relative w-full rounded-xl overflow-hidden"
      style={{
        background: "#0d1421",
        border: "1px solid rgba(255,255,255,0.08)",
        boxShadow: `0 0 40px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.04)`,
      }}
    >
      <canvas ref={canvasRef} style={{ display: "block", width: "100%", height: "400px" }} />

      {/* Overlay badge */}
      <div className="absolute top-3 left-3 flex items-center gap-2">
        <div
          className="flex items-center gap-2 rounded-lg px-2.5 py-1.5"
          style={{ background: "rgba(13,20,33,0.85)", border: "1px solid rgba(255,255,255,0.1)", backdropFilter: "blur(8px)" }}
        >
          <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: isPositive ? "#26a69a" : "#ef5350" }} />
          <span className="text-xs font-bold text-white">{assetSymbol}</span>
          <span className={`text-xs font-semibold ${isPositive ? "text-emerald-400" : "text-red-400"}`}>
            {isPositive ? "+" : ""}{priceChange.toFixed(2)}%
          </span>
        </div>
        <div
          className="rounded-lg px-2 py-1"
          style={{ background: "rgba(13,20,33,0.85)", border: "1px solid rgba(255,255,255,0.06)" }}
        >
          <span className="text-[10px] text-white/40 font-mono">M1 · OTC · AO VIVO</span>
        </div>
      </div>
    </div>
  );
}
